﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvancedProgramming_Lesson2.Models
{
    public class Movie
    {
     
        public int Id { get; set; }


        [Required(ErrorMessageResourceType = typeof(AdvancedProgramming_Lesson2.Properties.Resources),
    ErrorMessageResourceName = "Required")]
        public string Title { get; set; }


        [DataType(DataType.Date)]
        [Required(ErrorMessageResourceType = typeof(AdvancedProgramming_Lesson2.Properties.Resources),
    ErrorMessageResourceName = "Required")]
        public DateTime ReleaseDate { get; set; }


        [Required(ErrorMessageResourceType = typeof(AdvancedProgramming_Lesson2.Properties.Resources),
    ErrorMessageResourceName = "Required")]
        public string Genre { get; set; }

        [Range(0, 999.99, ErrorMessageResourceType = typeof(AdvancedProgramming_Lesson2.Properties.Resources),
    ErrorMessageResourceName = "Range")]
        [Required(ErrorMessageResourceType = typeof(AdvancedProgramming_Lesson2.Properties.Resources),
    ErrorMessageResourceName = "Required")]
        public decimal Price { get; set; }

        
        [Required(ErrorMessageResourceType = typeof(AdvancedProgramming_Lesson2.Properties.Resources),
    ErrorMessageResourceName = "Required")]
        public string Rating { get; set; }

        [StringLength(2)]
        [Required (ErrorMessageResourceType = typeof(AdvancedProgramming_Lesson2.Properties.Resources),
    ErrorMessageResourceName = "Required")]
        public string Oscar { get; set; }

    }
}
