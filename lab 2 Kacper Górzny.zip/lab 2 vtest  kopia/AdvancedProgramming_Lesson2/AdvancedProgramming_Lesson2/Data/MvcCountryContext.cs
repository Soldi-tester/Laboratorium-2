﻿using AdvancedProgramming_Lesson2.Models;
using Microsoft.EntityFrameworkCore;
using MvcCountry.Models;

namespace MvcCountry.Data

{
    public class MvcCountryContext : DbContext
    {
        public MvcCountryContext(DbContextOptions<MvcCountryContext> options)
        : base(options)
        {
        }
        public DbSet<Country> Country { get; set; }
    }
}
